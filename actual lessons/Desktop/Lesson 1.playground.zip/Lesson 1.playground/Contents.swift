//: Playground - noun: a place where people can play

import UIKit
var book_of_the_bible = "Mathew"
var verces = ["6:68", "6:47-48", "13:7", "12:16", "2:22", "14:16", "17, and 26", "16:12 and 13"]
for verce_index in verces {
    print(book_of_the_bible + " " + verce_index)
}
